import pandas as pd
df = pd.read_csv("E:\PML\Topic17\Workout_prediction\gym_members_exercise_tracking.csv")
print(df.columns)
# perform feature selection using RandomforestRegressor
selected_columns = ['Age', 'Weight (kg)', 'Height (m)',
                    'Session_Duration (hours)',
                    'Fat_Percentage', 'Water_Intake (liters)']

X = df.loc[:,selected_columns]
Y = df['Calories_Burned']

from sklearn.linear_model import Ridge
regressor = Ridge(alpha=0.1, max_iter=100 , random_state=7)
regressor.fit(X,Y)

import pickle
pickle.dump(regressor, open("model.pkl","wb"))

# verify the stored pickle
model = pickle.load(open("model.pkl","rb"))
print(model.__class__)

